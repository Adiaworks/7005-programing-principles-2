<?php

namespace Illuminate\Collections;

use RuntimeException;

class ItemNotFoundException extends RuntimeException
{
}
