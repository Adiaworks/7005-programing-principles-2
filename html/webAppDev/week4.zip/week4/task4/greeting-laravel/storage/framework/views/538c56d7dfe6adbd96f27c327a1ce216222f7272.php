<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/wp.css')); ?>">
</head>

<body>
  <h1>Greetings <?php $__env->startSection('name'); ?> user <?php echo $__env->yieldSection(); ?></h1>
  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('layouts.greetingFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH /var/www/html/webAppDev/week4/task4/greeting-laravel/resources/views/layouts/master.blade.php ENDPATH**/ ?>