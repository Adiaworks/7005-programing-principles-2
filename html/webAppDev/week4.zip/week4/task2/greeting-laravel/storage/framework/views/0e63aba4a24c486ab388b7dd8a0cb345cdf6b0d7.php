
<!DOCTYPE html>
<html>
  <head>
    <title>Greeting</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../../wp.css">
  </head>
  
  <body>  
    <p>
    Hello <?php echo e($user); ?>.
    Next year, you will be <?php echo e($age); ?> years old.

    <hr>
  </body>
</html><?php /**PATH /var/www/html/webAppDev/week4/greeting-laravel/resources/views/greeting.blade.php ENDPATH**/ ?>