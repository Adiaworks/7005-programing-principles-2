<!DOCTYPE html>
<html>
<head>
    <link href="{{ asset('css/wp.css')}}" rel="stylesheet">
    <title>@yield('title')</title>
</head>
<body>
     @yield('content')
</body>
</html>