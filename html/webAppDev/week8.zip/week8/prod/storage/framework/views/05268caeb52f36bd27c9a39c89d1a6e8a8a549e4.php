<!DOCTYPE html>
<html>
<head>
    <link href="<?php echo e(asset('css/wp.css')); ?>" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
     <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH /var/www/html/webAppDev/week8/task1/prod/resources/views/layouts/master.blade.php ENDPATH**/ ?>