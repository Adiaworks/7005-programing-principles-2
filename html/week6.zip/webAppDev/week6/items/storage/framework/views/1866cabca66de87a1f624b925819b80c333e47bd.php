<?php $__env->startSection('title'); ?>
  Item List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
    <h1><?php echo e($item->summary); ?></h1>
    <p><?php echo e($item->details); ?></p>
    <a href="<?php echo e(url("item_delete/$item->id")); ?>">Delete item</a><br><br><!--this absolute url refers to the file of item_delete.blade.php-->
    <a href="<?php echo e(url("item_update/$item->id")); ?>">Update item</a><br><br>
    <a href="<?php echo e(url("/")); ?>">Home</a><br>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week6/task1&2/items/resources/views/items/item_detail.blade.php ENDPATH**/ ?>