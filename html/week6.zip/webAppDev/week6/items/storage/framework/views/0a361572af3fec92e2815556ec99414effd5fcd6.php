<?php $__env->startSection('title'); ?>
  Delete Item
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
  <h1>Delete Item</h1>
    
    

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week6/task1&2/items/resources/views/items/item_delete.blade.php ENDPATH**/ ?>