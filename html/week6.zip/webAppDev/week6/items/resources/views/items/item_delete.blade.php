@extends('layouts.master')

@section('title')
  Delete Item
@endsection

@section('content') 
  <h1>Delete Item</h1>
    
    

 
@endsection