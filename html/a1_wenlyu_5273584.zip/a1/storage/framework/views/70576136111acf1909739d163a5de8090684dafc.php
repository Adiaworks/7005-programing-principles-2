<?php $__env->startSection('content'); ?> 
<h1>Update a user</h1>
<form method="post" action="<?php echo e(url("update_user_action/$user->id")); ?>">
<?php echo e(csrf_field()); ?>

<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
<p>
  <label>Name: </label>
  <input name="name" value="<?php echo e($user->name); ?>">
</p>
<p>
  <label>Age:</label>
  <input name="age" value="<?php echo e($user->age); ?>">
</p>
<p>
  <label>License_number: </label>
  <input name="license_number" value="<?php echo e($user->license_number); ?>">
</p>
<p>
  <label>License_type: </label>
  <input name="license_type" value="<?php echo e($user->license_type); ?>">
</p>
<input type="submit" value="Update this user">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/user_update.blade.php ENDPATH**/ ?>