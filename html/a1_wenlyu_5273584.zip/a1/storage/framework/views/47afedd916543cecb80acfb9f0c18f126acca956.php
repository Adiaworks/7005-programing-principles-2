  <?php $__env->startSection('content'); ?>
  <h1>Book a vehicle</h1>
  <form method="post" action="<?php echo e(url("booking_action")); ?>">
    <?php echo e(csrf_field()); ?>

    <p>
      <label>Your user id</label>
      <select name="user_id" id="user_id">
        <?php if($users): ?>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"><?php echo e($user->id); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          No item found
        <?php endif; ?>
      </select>
    </p>
    <p>
      <label>Your user name</label>
      <select name="user_name" id="user_name">
        <?php if($users): ?>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          No item found
        <?php endif; ?>
      </select>
    </p>
    <p>
      <label>Your license number</label>
      <select name="license_number" id="license_number">
        <?php if($users): ?>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->license_number); ?>"><?php echo e($user->license_number); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          No item found
        <?php endif; ?>
      </select>
    </p>
    <p>
      <label>Vehicle rego</label>
      <select name="vehicle_rego" id="vehicle_rego">
        <?php if($vehicles): ?>
          <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($vehicle->rego); ?>"><?php echo e($vehicle->rego); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          No item found
        <?php endif; ?>
      </select>
    </p>
    <p>
      <label>Starting date</label>
      <input type="date" id="starting_date" name="starting_date">
    </p>
    <p>
      <label>Starting time</label>
      <input type="time" id="starting_time" name="starting_time">
    </p>
    <p>
      <label>Returning date</label>
      <input type="date" id="returning_date" name="returning_date">
    </p>    
    <p>
      <label>Returning time</label>
      <input type="time" id="returning_time" name="returning_time">
    </p>
    <input type="submit" value="Book"><br><br>
  </form>
  <a href="<?php echo e(url("booking_frequency")); ?>">List vehicles by booking frequency</a><br><br>
  <a href="<?php echo e(url("booking_time_list")); ?>">List vehicles by the amount of booking time</a><br><br>
  <a href="<?php echo e(url("booking_list")); ?>">List all the bookings</a><br><br>
  <a href="<?php echo e(url("list_vehicles")); ?>">Home</a>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/book_a_vehicle.blade.php ENDPATH**/ ?>