<?php $__env->startSection('title'); ?>
  Delete user
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
  <h1>User deleted</h1>
  <a href="<?php echo e(url("list_users")); ?>">List users</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/user_delete.blade.php ENDPATH**/ ?>