<?php $__env->startSection('content'); ?>
  <h1>Vehicles</h1>

  <ul class="list-group">
  <?php if($vehicles): ?>
    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="list-group-item list-group-item-action"><a href="<?php echo e(url("vehicle_detail/$vehicle->id")); ?>"><?php echo e($vehicle->rego); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    <li class="list-group-item">No item found</li>
  <?php endif; ?>
  </ul>

  <a type="button" class="btn btn-primary" href="<?php echo e(url("create_a_vehicle/$vehicle->id")); ?>">Create a vehicle</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/vehicle_list.blade.php ENDPATH**/ ?>