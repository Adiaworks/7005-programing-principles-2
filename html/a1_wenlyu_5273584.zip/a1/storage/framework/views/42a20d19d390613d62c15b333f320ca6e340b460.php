<?php $__env->startSection('content'); ?>
  <h1>Create a vehicle</h1>

  <form method="post" action="<?php echo e(url("create_vehicle_action")); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="mb-3">
      <label for="rego" class="form-label">Rego:</label>
      <input type="text" class="form-control" id="rego" name="rego" >
    </div>
    <div class="mb-3">
      <label for="model" class="form-label">Model:</label>
      <input type="text" class="form-control" id="model" name="model" >
    </div>
    <div class="mb-3">
      <label for="year" class="form-label">Year:</label>
      <input type="text" class="form-control" id="year" name="year" >
    </div>
    <div class="mb-3">
      <label for="odometer" class="form-label">Odometer:</label>
      <input type="text" class="form-control" id="odometer" name="odometer" >
    </div>
    <input type="submit" class="btn btn-primary" value="Create">
  </form>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/create_a_vehicle.blade.php ENDPATH**/ ?>