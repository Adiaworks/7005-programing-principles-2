<?php $__env->startSection('content'); ?>
  <div class="card" style="width: 18rem;">
  <div class="card-body">
      <h5 class="card-title">Vehicle Details</h5>
      <p class="card-text">Rego: <?php echo e($vehicle->rego); ?></p>
      <p class="card-text">ID: <?php echo e($vehicle->id); ?></p>
      <p class="card-text">Model: <?php echo e($vehicle->model); ?></p>
      <p class="card-text">Year: <?php echo e($vehicle->year); ?></p>
      <p class="card-text">Odometer: <?php echo e($vehicle->odometer); ?></p>
      <a class="card-link" href="<?php echo e(url("booking_information/$vehicle->id")); ?>">Booking information of this vehicle</a><br><br>
      <a class="card-link" href="<?php echo e(url("vehicle_delete/$vehicle->id")); ?>">Delete vehicle</a><br><br>
      <a class="card-link" href="<?php echo e(url("vehicle_update/$vehicle->id")); ?>">Update vehicle</a><br><br>
      <a class="card-link" href="<?php echo e(url("create_a_vehicle/$vehicle->id")); ?>">Create a vehicle</a><br><br>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/vehicle_detail.blade.php ENDPATH**/ ?>