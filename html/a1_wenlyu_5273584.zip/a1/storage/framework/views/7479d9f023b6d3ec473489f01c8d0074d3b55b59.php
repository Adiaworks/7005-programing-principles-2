<?php $__env->startSection('content'); ?> 
  <h1>Update a vehicle</h1>

  <form method="post" action="<?php echo e(url("update_vehicle_action/$vehicle->id")); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($vehicle->id); ?>">
    <div class="mb-3">
      <label for="rego" class="form-label">Rego:</label>
      <input type="text" class="form-control" id="rego" name="rego" value="<?php echo e($vehicle->rego); ?>" >
    </div>
    <div class="mb-3">
      <label for="model" class="form-label">Model:</label>
      <input type="text" class="form-control" id="model" name="model" value="<?php echo e($vehicle->model); ?>" >
    </div>
    <div class="mb-3">
      <label for="year" class="form-label">Year:</label>
      <input type="text" class="form-control" id="year" name="year" value="<?php echo e($vehicle->year); ?>" >
    </div>
    <div class="mb-3">
      <label for="odometer" class="form-label">Odometer:</label>
      <input type="text" class="form-control" id="odometer" name="odometer" value="<?php echo e($vehicle->odometer); ?>" >
    </div>
    <input type="submit" class="btn btn-primary" value="Update this vehicle">
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/vehicle_update.blade.php ENDPATH**/ ?>