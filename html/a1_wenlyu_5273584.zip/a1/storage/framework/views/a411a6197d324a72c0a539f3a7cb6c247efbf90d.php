  <?php $__env->startSection('content'); ?>
  <h1>Return a vehicle</h1>
  <form method="post" action="<?php echo e(url("return_vehicle_action")); ?>">
    <?php echo e(csrf_field()); ?>

    <p>
      <label>Distance driven</label>
      <input type="number" name="distance" >
    </p>
    <p>
      <label>Booking id</label>
      <input type="number" name="booking_id" >
    </p>
    <p>
      <label>User name</label>
      <input type="text" name="user_name" >
    </p>
    <p>
      <label>Vehicle id</label>
      <input type="number" name="vehicle_id" >
    </p>
    <input type="submit" value="Submit"><br>
  </form>
  <a href="<?php echo e(url("list_vehicles")); ?>">Home</a>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/return_a_vehicle.blade.php ENDPATH**/ ?>