<?php $__env->startSection('content'); ?>
<h1>Users</h1>
  <?php if($users): ?>
  <table style="width:100%">
      <tr>
        <th>User ID</th>
        <th>User name</th>
        <th>User age</th>
        <th>License number</th>
        <th>License type</th>
        <th>Delete</th>
        <th>Update</th>
      </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($user->id); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->age); ?></td>
        <td><?php echo e($user->license_number); ?></td>
        <td><?php echo e($user->license_type); ?></td>   
        <td><a href="<?php echo e(url("user_delete/$user->id")); ?>">Delete</a></td>
        <td><a href="<?php echo e(url("user_update/$user->id")); ?>">Update</a></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
  </table>
  <?php else: ?>
    No item found
  <?php endif; ?>
<a href="<?php echo e(url("create_a_user/$user->id")); ?>">Create a user</a><br>
<a href="<?php echo e(url("list_vehicles")); ?>">Home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/user_detail.blade.php ENDPATH**/ ?>