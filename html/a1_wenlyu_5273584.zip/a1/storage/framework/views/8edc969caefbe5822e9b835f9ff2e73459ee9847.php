<?php $__env->startSection('content'); ?>
<h1>Booking time list in a descending order</h1>
  <?php if($bookings): ?>
  <table style="width:160%">
      <tr>
        <th>Vehicle id</th>
        <th>Total booking time(days)</th>
      </tr>
    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($booking->vehicle_id); ?></td>
        <td><?php echo e(round($booking->booking_sum, 2)); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php else: ?>
    No item found
  <?php endif; ?>
<a href="<?php echo e(url("booking_list")); ?>">List all the bookings</a><br><br>
<a href="<?php echo e(url("list_vehicles")); ?>">Home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/booking_time_list.blade.php ENDPATH**/ ?>