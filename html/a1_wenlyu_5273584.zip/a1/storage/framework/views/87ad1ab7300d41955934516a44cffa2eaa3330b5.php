<?php $__env->startSection('content'); ?> 
<h1>Booking detail</h1>
<p>ID: <?php echo e($booking->id); ?></p>
<p>User id: <?php echo e($booking->user_id); ?></p>
<p>User name: <?php echo e($booking->user_name); ?></p> 
<p>User license_number: <?php echo e($booking->user_license_number); ?></p> 
<p>Starting date: <?php echo e($booking->starting_date); ?></p>
<p>Starting time: <?php echo e($booking->starting_time); ?></p>
<p>Returning date: <?php echo e($booking->returning_date); ?></p>
<p>Returning time: <?php echo e($booking->returning_time); ?></p>
<a href="<?php echo e(url("booking_frequency")); ?>">List vehicles by booking numbers</a><br><br>
<a href="<?php echo e(url("booking_time")); ?>">List vehicles by the amount of booking time</a><br><br>
<a href="<?php echo e(url("booking_list")); ?>">List all the bookings</a><br><br>
<a href="<?php echo e(url("list_vehicles")); ?>">Home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/booking_detail.blade.php ENDPATH**/ ?>