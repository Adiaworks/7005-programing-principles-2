<?php $__env->startSection('content'); ?>
<h1>Bookings</h1>
  <?php if($bookings): ?>
    <table style="width:100%">
      <tr>
        <th>Booking ID</th>
        <th>User ID</th>
        <th>User name</th>
        <th>license number</th>
        <th>Vehicle ID</th>
        <th>Starting date</th>
        <th>Starting time</th>
        <th>Returning date</th>
        <th>Returning time</th>
      </tr>
    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($booking->id); ?></td>
        <td><?php echo e($booking->user_id); ?></td>
        <td><?php echo e($booking->user_name); ?></td>
        <td><?php echo e($booking->user_license_number); ?></td>
        <td><?php echo e($booking->vehicle_id); ?></td>
        <td><?php echo e($booking->starting_date); ?></td>
        <td><?php echo e($booking->starting_time); ?></td>
        <td><?php echo e($booking->returning_date); ?></td>
        <td><?php echo e($booking->returning_time); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  <?php else: ?>
    No item found
  <?php endif; ?>
<a href="<?php echo e(url("list_vehicles")); ?>">Home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a1/resources/views/items/booking_information.blade.php ENDPATH**/ ?>