@extends('layouts.master')

@section('content') 
  <h1>Vehicle deleted</h1>
  <a type="button" class="btn btn-primary" href="{{url("list_vehicles")}}">List vehicles</a>
@endsection