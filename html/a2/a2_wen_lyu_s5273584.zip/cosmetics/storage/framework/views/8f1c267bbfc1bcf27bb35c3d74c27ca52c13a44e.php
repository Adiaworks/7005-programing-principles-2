<?php $__env->startSection('title'); ?>
    Reviews
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-light">
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <?php if($reviews): ?>
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card shadow-sm">
                        <title>Placeholder</title>
                        <div class="card-body">
                            <p class="card-text">Item: <?php echo e($review->item->name); ?></p> 
                            <p class="card-text">Rating: <?php echo e($review->rating); ?></p>
                            <p class="card-text">Review: <?php echo e($review->content); ?></p>
                            <p class="card-text">User: <?php echo e($review->user->name); ?></p>
                            <p class="card-text"><?php echo e($review->review_created_at); ?></p> 
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if((Auth::user()->following) === ''): ?> 
                                <?php if(($review->user_id) != (Auth::user()->id)): ?>
                                    <form method="POST" style="text-align:center;" action= '<?php echo e(url("user/follow/$review->user_id")); ?>'>
                                    <?php echo e(csrf_field()); ?>

                                    <input type="submit" value="Follow this user">
                                </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(str_contains(Auth::user()->following, $review->user_id)): ?>
                                    <form method="POST" style="text-align:center;" action= '<?php echo e(url("user/unfollow/$review->user_id")); ?>'>
                                        <?php echo e(csrf_field()); ?>

                                        <input type="submit" value="Unfollow this user">
                                    </form>
                                <?php elseif(($review->user_id) != (Auth::user()->id)): ?>
                                    <form method="POST" style="text-align:center;" action= '<?php echo e(url("user/follow/$review->user_id")); ?>'>
                                        <?php echo e(csrf_field()); ?>

                                        <input type="submit" value="Follow this user">
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h1>No review found</h1>
        <?php endif; ?>
        </div>
    </div>
</div>

<div id="outer">  
    <div id="inner"><?php echo e($reviews->links()); ?></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/reviews/index.blade.php ENDPATH**/ ?>