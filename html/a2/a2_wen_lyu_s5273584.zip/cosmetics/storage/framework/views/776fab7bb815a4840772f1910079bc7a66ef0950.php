<?php $__env->startSection('title'); ?>
    Item Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert"> 
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </ul>
        </div>
    <?php endif; ?>
    <form method="POST" action='<?php echo e(url("item")); ?>' enctype="multipart/form-data"> <!--goes to the store function in the controller via product route -->
        <?php echo e(csrf_field()); ?>

        <br>
        <p>
            <label>Name </label><input type="text" name="name" value="<?php echo e(old('name')); ?>"> <!--once error exists, it will direct back to this form and retrieve the value user input -->
        </p>
        
        <p>
            <label>Price </label><input type="text" name="price"value="<?php echo e(old('price')); ?>">
        </p>
        
        <p>
            <label>Manufacture </label><input type="text" name="manufacture_name"value="<?php echo e(old('manufacture_name')); ?>">
        </p>
        
        <p>
            <label>Description </label>
            <input type="text" name="description"value="<?php echo e(old('description')); ?>">
        </p>   
        
        <p>
            <label>URL </label>
            <input type="text" name="URL"value="<?php echo e(old('URL')); ?>">
        </p>

        <p>
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        </p>

        <div class="custom-file">
                <input type="file" name="images[]" class="custom-file-input" id="images" multiple="multiple">
        </div>
        
        <br><div>
        <input type="submit" value="Create"> 
        </div>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/items/create_form.blade.php ENDPATH**/ ?>