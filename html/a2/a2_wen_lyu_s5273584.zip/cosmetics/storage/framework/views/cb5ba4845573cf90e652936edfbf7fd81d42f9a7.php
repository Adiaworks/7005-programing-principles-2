<?php $__env->startSection('title'); ?>
    Show items
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2><?php echo e($item->name); ?></h2>
    
    <?php if($item->image != ""): ?>
        <!--- check whether the item has images or not --->
        <?php $__currentLoopData = explode(',', $item->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(url($image)); ?>" style="object-fit: cover" width="30%" height="300px" alt="cosmetic images" role="img">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No Images</p>
    <?php endif; ?>
    
    <p><b>Price: </b><?php echo e($item->price); ?></p>
    <p><b>Manufacture: </b><?php echo e($item->manufacture_name); ?></p>
    <p><b>Description: </b><?php echo e($item->description); ?></p>
       
    <?php if($item->URL): ?>
        <!--- check whether the item has URL or not --->
        <p>
        <label><b>URL:</b></label>
        <a href="<?php echo e($item->URL); ?>">Check this product</a>
        </p>
    <?php else: ?>
        <p><b>URL: </b> No URL</p>
    <?php endif; ?>
    
    <p>
        <label><b> Reviews:</b></label>
    </p>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!--- loop through all the reviews and display their content --->
        <?php if($review->dislike === NULL && $review->like === NULL): ?>
            <div class="card" style="background-color:white" id="inner">
                <div class="container">
                    <p>Rating: <?php echo e($review->rating); ?></p>
                    <p>Review: <?php echo e($review->content); ?></p>
                    <p>Created by: <?php echo e($review->user->name); ?> <?php echo e($review->created_at); ?></p>
                    <div class="line-up">
                    <?php if(auth()->guard()->check()): ?>
                    <!--- user is logged in --->
                    <form method="POST" action= '<?php echo e(url("review/like/$review->id")); ?>'>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Like(<?php echo e((count(explode(',', $review->like))-1)); ?>)">
                        
                    </form>
                    <form method="POST" action= '<?php echo e(url("review/dislike/$review->id")); ?>'>
                        <?php echo e(csrf_field()); ?> 
                        <input type="submit" value="Dislike(<?php echo e((count(explode(',', $review->dislike))-1)); ?>)">
                        
                    </form>
                        <?php if(Auth::user()->type === "Moderator"): ?>                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                    
                        <?php elseif($review->user->id === Auth::user()->id): ?>
                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php elseif($review->dislike === NULL && $review->like != NULL && ((count(explode(',', $review->dislike))-1) < count(explode(',', $review->like)))): ?>
            <div class="card" style="background-color:peachpuff" id="inner">
                <div class="container">
                    <p>Rating: <?php echo e($review->rating); ?></p>
                    <p>Review: <?php echo e($review->content); ?></p>
                    <p>Created by: <?php echo e($review->user->name); ?> <?php echo e($review->created_at); ?></p>

                    <div class="line-up">
                    <?php if(auth()->guard()->check()): ?>
                    <!--- user is logged in --->
                        <form method="POST" action= '<?php echo e(url("review/like/$review->id")); ?>'>
                            <?php echo e(csrf_field()); ?>

                            <input type="submit" value="Like(<?php echo e((count(explode(',', $review->like)))); ?>)">
                            
                        </form>
                        <form method="POST" action= '<?php echo e(url("review/dislike/$review->id")); ?>'>
                            <?php echo e(csrf_field()); ?> 
                            <input type="submit" value="Dislike(<?php echo e((count(explode(',', $review->dislike))-1)); ?>)">
                            
                        </form>
                    
                        <?php if(Auth::user()->type === "Moderator"): ?>                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                    
                        <?php elseif($review->user->id === Auth::user()->id): ?>
                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php elseif($review->dislike != NULL && $review->like != NULL && ((count(explode(',', $review->dislike))) < count(explode(',', $review->like)))): ?>
            <div class="card" style="background-color:peachpuff" id="inner">
                <div class="container">
                    <p>Rating: <?php echo e($review->rating); ?></p>
                    <p>Review: <?php echo e($review->content); ?></p>
                    <p>Created by: <?php echo e($review->user->name); ?> <?php echo e($review->created_at); ?></p>
                    <div class="line-up">
                    <?php if(auth()->guard()->check()): ?>
                    <!--- user is logged in --->
                        <form method="POST" action= '<?php echo e(url("review/like/$review->id")); ?>'>
                            <?php echo e(csrf_field()); ?>

                            <input type="submit" value="Like(<?php echo e((count(explode(',', $review->like)))); ?>)">
                            
                        </form>
                        <form method="POST" action= '<?php echo e(url("review/dislike/$review->id")); ?>'>
                            <?php echo e(csrf_field()); ?> 
                            <input type="submit" value="Dislike(<?php echo e((count(explode(',', $review->dislike)))); ?>)">
                            
                        </form>
                        <?php if(Auth::user()->type === "Moderator"): ?>                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                    
                        <?php elseif($review->user->id === Auth::user()->id): ?>
                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div> 
            </div> 
        <?php elseif($review->dislike != NULL && $review->like != NULL && ((count(explode(',', $review->dislike))) > count(explode(',', $review->like)))): ?>
            <div class="card" style="background-color:oldlace" id="inner">
                <div class="container">
                    <p>Rating: <?php echo e($review->rating); ?></p>
                    <p>Review: <?php echo e($review->content); ?></p>
                    <p>Created by: <?php echo e($review->user->name); ?> <?php echo e($review->created_at); ?></p>
                    <div class="line-up">
                    <?php if(auth()->guard()->check()): ?>
                    <!--- user is logged in --->
                    <form method="POST" action= '<?php echo e(url("review/like/$review->id")); ?>'>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Like(<?php echo e((count(explode(',', $review->like)))); ?>)">
                        
                    </form>
                    <form method="POST" action= '<?php echo e(url("review/dislike/$review->id")); ?>'>
                        <?php echo e(csrf_field()); ?> 
                        <input type="submit" value="Dislike(<?php echo e((count(explode(',', $review->dislike)))); ?>)">
                        
                    </form>
                    
                        <?php if(Auth::user()->type === "Moderator"): ?>                        
                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                    
                        <?php elseif($review->user->id === Auth::user()->id): ?>
                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div> 
            </div>
        <?php elseif($review->dislike != NULL && $review->like != NULL && ((count(explode(',', $review->dislike))) == count(explode(',', $review->like)))): ?>
            <div class="card" style="background-color:white" id="inner">
                <div class="container">
                    <p>Rating: <?php echo e($review->rating); ?></p>
                    <p>Review: <?php echo e($review->content); ?></p>
                    <p>Created by: <?php echo e($review->user->name); ?> <?php echo e($review->created_at); ?></p>

                    <div class="line-up">
                    <?php if(auth()->guard()->check()): ?>
                    <!--- user is logged in --->
                        <form method="POST" action= '<?php echo e(url("review/like/$review->id")); ?>'>
                            <?php echo e(csrf_field()); ?>

                            <input type="submit" value="Like(<?php echo e((count(explode(',', $review->like)))); ?>)">
                            
                        </form>
                        <form method="POST" action= '<?php echo e(url("review/dislike/$review->id")); ?>'>
                            <?php echo e(csrf_field()); ?> 
                            <input type="submit" value="Dislike(<?php echo e((count(explode(',', $review->dislike)))); ?>)">
                            
                        </form>
                        <?php if(Auth::user()->type === "Moderator"): ?>                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                    
                        <?php elseif($review->user->id === Auth::user()->id): ?>
                        
                            <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <input type="submit" value="Edit">
                            </form>

                            <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" value="Delete">
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div> 
            </div>
        <?php else: ?>
            <div class="card" style="background-color:oldlace" id="inner">
                <div class="container">
                    <p>Rating: <?php echo e($review->rating); ?></p>
                    <p>Review: <?php echo e($review->content); ?></p>
                    <p>Created by: <?php echo e($review->user->name); ?> <?php echo e($review->created_at); ?></p>
                    <div class="line-up">
                        <?php if(auth()->guard()->check()): ?>
                        <!--- user is logged in --->
                            <form method="POST" action= '<?php echo e(url("review/like/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Like(<?php echo e((count(explode(',', $review->like))-1)); ?>)">
                                
                            </form>
                            <form method="POST" action= '<?php echo e(url("review/dislike/$review->id")); ?>'>
                                <?php echo e(csrf_field()); ?> 
                                <input type="submit" value="Dislike(<?php echo e((count(explode(',', $review->dislike)))); ?>)">
                                
                            </form>
                            <?php if(Auth::user()->type === "Moderator"): ?>                        
                                <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                    <?php echo e(csrf_field()); ?>

                                    <input type="submit" value="Edit">
                                </form>

                                <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                    <?php echo e(csrf_field()); ?> 
                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="submit" value="Delete">
                                </form>
                        
                            <?php elseif($review->user->id === Auth::user()->id): ?>
                            
                                <form method="GET" action= '<?php echo e(url("review/$review->id/edit")); ?>'>
                                    <?php echo e(csrf_field()); ?> 
                                    <input type="submit" value="Edit">
                                </form>

                                <form method="POST" action= '<?php echo e(url("review/$review->id")); ?>'>
                                    <?php echo e(csrf_field()); ?> 
                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="submit" value="Delete">
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(auth()->guard()->check()): ?> 
    <div id="inner">
        <?php if(Auth::user()->type === "Moderator"): ?>
            <form method="GET" action= '<?php echo e(url("item/$item->id/edit")); ?>'>
                <?php echo e(csrf_field()); ?>

                <input type="submit" value="Edit this item">
            </form><br>
    
            <form method="POST" action= '<?php echo e(url("item/$item->id")); ?>'>
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Delete this item">
            </form><br>
        <?php endif; ?>
        
        <form method="GET" action= '<?php echo e(url("item/create")); ?>'>
            <?php echo e(csrf_field()); ?> 
            <input type="submit" value="Create an item">
        </form>

        <form method="GET" action= '<?php echo e(url("review/create_a_review/$item->id")); ?>'>
            <?php echo e(csrf_field()); ?> 
            <input type="submit" value="Create a review">
        </form>
       
        <form method="GET" action= '<?php echo e(url("item/upload_images/$item->id")); ?>'>
            <?php echo e(csrf_field()); ?> 
            <input type="submit" value="Upload images">
        </form>
    </div><br>    

    <?php endif; ?>

    <br><div id="outer">  
        <div id="inner"><?php echo e($reviews->links()); ?></div>
    </div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/items/show.blade.php ENDPATH**/ ?>