<?php $__env->startSection('title'); ?>
    User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h2>Hi <?php echo e(Auth::user()->name); ?>!</h2>
    <p>User type: <?php echo e(Auth::user()->type); ?></p>
    <p>
        <a href='<?php echo e(url("user/recommendation", Auth::user()->id)); ?>'>Recommendation</a>
    </p>
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            
            <?php if(Auth::user()->following != NULL): ?>
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card shadow-sm">
                            <div class="card-body">
                            <p class="card-text">Item: <?php echo e($review->item->name); ?></p> 
                            <p class="card-text">Rating: <?php echo e($review->rating); ?></p>
                            <p class="card-text">Review: <?php echo e($review->content); ?></p>
                            <p class="card-text">User: <?php echo e($review->user->name); ?></p>
                            <p class="card-text"><?php echo e($review->review_created_at); ?></p>
                            
                            <?php if(str_contains($user->following, $review->user_id)): ?>
                                <form method="POST" style="text-align:center;" action= '<?php echo e(url("user/unfollow/$review->user_id")); ?>'>
                                    <?php echo e(csrf_field()); ?>

                                    <input type="submit" value="Unfollow this user">
                                </form>
                            <?php endif; ?>
                            
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p><b>Following: </b> No following now</p>
            <?php endif; ?>
            
            </div>
        </div>
    </div>            

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/users/show.blade.php ENDPATH**/ ?>