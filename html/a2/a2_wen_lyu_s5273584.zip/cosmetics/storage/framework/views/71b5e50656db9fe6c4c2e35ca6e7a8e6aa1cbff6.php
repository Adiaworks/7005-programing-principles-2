<?php $__env->startSection('title'); ?>
    Review Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <!--- check if there is any errors and then display it --->
        <div class="alert"> 
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <li><?php echo e($error); ?></>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </ul>
        </div>
    <?php endif; ?>
        <form method="POST" action='<?php echo e(url("review")); ?>'> <!--goes to the store function in the controller via review route -->
            <?php echo e(csrf_field()); ?>

        
            <br>
            <p>
                <label>Rating (from 1 to 5) </label>
                <input type="numeric" name="rating" value="<?php echo e(old('rating')); ?>">
            </p>
        
            <p>
                <label>Content </label><input type="text" name="content"value="<?php echo e(old('content')); ?>">
            </p>
        
            <p>
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">     
            </p>
        
            <p> 
                <input type="hidden" name="item_id" value="<?php echo e($item_id); ?>">
            </p>   
        
            <input type="submit" value="Create"> 
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/reviews/create_form.blade.php ENDPATH**/ ?>