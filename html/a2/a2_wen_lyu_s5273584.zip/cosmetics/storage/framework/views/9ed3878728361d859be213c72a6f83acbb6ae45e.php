<?php $__env->startSection('title'); ?>
    Item Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action='<?php echo e(url("item/$item->id")); ?>' enctype="multipart/form-data"> <!--goes to the update function in the controller -->
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

        <br>
        <p>
            <label>Name </label>
            <input type="text" name="name" value="<?php echo e($item->name); ?>">
            <div class="alert">
                <?php echo e($errors->first('name')); ?>

            </div>
        </p>
        
        <p>
            <label>Price </label>
            <input type="text" name="price" value="<?php echo e($item->price); ?>">
            <div class="alert">
                <?php echo e($errors->first('price')); ?>

            </div>
        </p>
        
        <p>
            <label>Manufacture </label>
            <input type="text" name="manufacture_name" value="<?php echo e($item->manufacture_name); ?>">
            <div class="alert">
                <?php echo e($errors->first('manufacture_name')); ?>

            </div>
        </p>
        
        <p>
            <label>Description </label>
            <input type="text" name="description" value="<?php echo e($item->description); ?>">
            <div class="alert">
                <?php echo e($errors->first('description')); ?>

            </div>
        </p>

        <p>
            <label>URL </label>
            <input type="text" name="URL" value="<?php echo e($item->URL); ?>">
            <div class="alert">
                <?php echo e($errors->first('URL')); ?>

            </div>
        </p>

        <div class="custom-file">
            <input type="file" name="images[]" class="custom-file-input" id="images" multiple="multiple" value="<?php echo e($item->image); ?>">
            <label>Images </label>
            <div class="alert">
                <?php echo e($errors->first('image')); ?>

            </div>
        </div>

        <p>
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        </p>

        <input type="submit" value="Update"> 
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/items/edit_form.blade.php ENDPATH**/ ?>