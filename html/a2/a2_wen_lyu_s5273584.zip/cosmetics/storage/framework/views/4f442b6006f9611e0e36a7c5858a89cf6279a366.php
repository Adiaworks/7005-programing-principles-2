<?php $__env->startSection('title'); ?>
Recommendation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>
    Recommendation
</p>
<div class="album py-5 bg-light">
    <div class="container">
        <div>
            <p>Popular Items in following:</p>
        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

            <?php if(count($items) != 0): ?>

            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <?php echo e($item->name); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">Price: <?php echo e($item->price); ?></p>
                        <p class="card-text">Manufacture: <?php echo e($item->manufacture_name); ?></p>
                        <p class="card-text">Description: <?php echo e($item->description); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p><b>Recommendation: </b>Please follow some people firstly.</p>
            <?php endif; ?>

        </div>

        <div>
            <p>Popular Users in following:</p>
        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

            <?php if(count($users) != 0): ?>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <?php echo e($user->name); ?>

                    </div>
                    <div class="card-body">
                        <p class="card-text">Email: <?php echo e($user->email); ?></p>
                        <p class="card-text">User type: <?php echo e($user->type); ?></p>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if((Auth::user()->following) === ''): ?>
                    <?php if(($user->id) != (Auth::user()->id)): ?>
                    <form method="POST" style="text-align:center;" action='<?php echo e(url("user/follow/$user->id")); ?>'>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Follow this user">
                    </form>
                    <?php endif; ?>
                    <?php else: ?>
                    <?php if(str_contains(Auth::user()->following, $user->id)): ?>
                    <form method="POST" style="text-align:center;" action='<?php echo e(url("user/unfollow/$user->id")); ?>'>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Unfollow this user">
                    </form>
                    <?php elseif(($user->id) != (Auth::user()->id)): ?>
                    <form method="POST" style="text-align:center;" action='<?php echo e(url("user/follow/$user->id")); ?>'>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Follow this user">
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p><b>Recommendation: </b>Please follow some people firstly.</p>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/users/recommendation.blade.php ENDPATH**/ ?>