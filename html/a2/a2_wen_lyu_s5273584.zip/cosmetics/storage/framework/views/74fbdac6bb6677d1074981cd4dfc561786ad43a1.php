<?php $__env->startSection('title'); ?>
    Upload images
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2>Upload your images here</h2><br>
    <form method="POST" action='<?php echo e(url("item/store_images/$item->id")); ?>' enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?> 
        <div class="custom-file">
            <input type="file" name="images[]" class="custom-file-input" id="images" multiple="multiple">
        </div>
        <p>
            <input type="hidden" name="user_name" value="<?php echo e(Auth::user()->name); ?>">
        </p>
        <br><div>
        <input type="submit" value="Upload"> 
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/items/upload_images.blade.php ENDPATH**/ ?>