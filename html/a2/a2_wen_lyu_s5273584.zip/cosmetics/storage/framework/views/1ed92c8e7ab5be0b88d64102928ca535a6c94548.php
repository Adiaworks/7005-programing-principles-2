<?php $__env->startSection('title'); ?>
    All items
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-light">
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <?php if($items): ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="<?php echo e(url(explode(',',$item->image)[0])); ?>" width="100%" height="300px" style="object-fit: cover" alt="cosmetic images" role="img">
                            <title>Placeholder</title>
                            <rect width="100%" height="100%" fill="#55595c" />                   
                            <div class="card-body">
                                <p class="card-text"><a href='<?php echo e(url("item/$item->id")); ?>'><?php echo e($item->name); ?></a></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h1>No item found</h1>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/items/index.blade.php ENDPATH**/ ?>