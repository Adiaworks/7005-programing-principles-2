<?php $__env->startSection('title'); ?>
    Review Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action='<?php echo e(url("review/$review->id")); ?>'> <!--goes to the update function in the controller -->
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

        <br>
        <p>
            <label>Rating </label>
            <input type="numeric" name="rating" value="<?php echo e($review->rating); ?>">
            <div class="alert">
                <?php echo e($errors->first('rating')); ?>

            </div>
        </p>
        
        <p>
            <label>Content </label>
            <input type="text" name="content"value="<?php echo e($review->content); ?>">
            <div class="alert">
                <?php echo e($errors->first('content')); ?>

            </div>
        </p>
        
        <p>
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">  
        </p>
        
        <p>
            <input type="hidden" name="item_id" value="<?php echo e($item_id); ?>"> 
        </p>

        <p>
            <input type="hidden" name="like" value="<?php echo e($review->like); ?>"> 
        </p>

        <p>
            <input type="hidden" name="dislike" value="<?php echo e($review->dislike); ?>"> 
        </p>

        <input type="submit" value="Update"> 
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/reviews/edit_form.blade.php ENDPATH**/ ?>