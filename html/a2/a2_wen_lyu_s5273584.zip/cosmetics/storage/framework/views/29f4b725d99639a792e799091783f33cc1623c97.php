<?php $__env->startSection('content'); ?>

    <h2><?php echo e($review->name); ?></h2>
    <p>Content: <?php echo e($review->content); ?></p>
    <p>User: <?php echo e($review->user->name); ?></p>
    <p>Created at: <?php echo e($review->created_at); ?></p>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/a2/cosmetics/resources/views/reviews/show.blade.php ENDPATH**/ ?>